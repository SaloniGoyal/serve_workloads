ARTICLE_TEXT_KEY = "summary_text"
